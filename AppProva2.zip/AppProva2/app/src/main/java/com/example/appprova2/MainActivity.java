package com.example.appprova2;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    private EditText etNome, etSalario, etNumFilhos;
    private RadioGroup rgSexo;
    private RadioButton rbMasculino, rbFeminino;
    private TextView tvInss, tvIr, tvSalarioLiquido;
    private Button btnCalcular;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializando componentes
        etNome = findViewById(R.id.et_nome);
        etSalario = findViewById(R.id.et_salario);
        etNumFilhos = findViewById(R.id.et_num_filhos);
        rgSexo = findViewById(R.id.rg_sexo);
        rbMasculino = findViewById(R.id.rb_masculino);
        rbFeminino = findViewById(R.id.rb_feminino);
        tvInss = findViewById(R.id.tv_inss);
        tvIr = findViewById(R.id.tv_ir);
        tvSalarioLiquido = findViewById(R.id.tv_salario_liquido);
        btnCalcular = findViewById(R.id.btn_calcular);

        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calcularSalario();
            }
        });
    }

    private void calcularSalario() {
        try {
            // Pegando os valores dos campos
            String nome = etNome.getText().toString();
            double salarioBruto = Double.parseDouble(etSalario.getText().toString());
            int numFilhos = Integer.parseInt(etNumFilhos.getText().toString());

            // Validando entrada de salário e número de filhos
            if (salarioBruto < 0 || numFilhos < 0) {
                Toast.makeText(this, "Salário ou número de filhos inválido!", Toast.LENGTH_SHORT).show();
                return;
            }

            // Determinando o tratamento
            String tratamento = "";
            if (rbMasculino.isChecked()) {
                tratamento = "Sr.";
            } else if (rbFeminino.isChecked()) {
                tratamento = "Sra.";
            }

            // Cálculo do INSS
            double inss = calcularINSS(salarioBruto);

            // Cálculo do IR
            double ir = calcularIR(salarioBruto);

            // Cálculo do Salário Família
            double salarioFamilia = 0;
            if (salarioBruto <= 1212.00) {
                salarioFamilia = 56.47 * numFilhos;
            }

            // Cálculo do Salário Líquido
            double salarioLiquido = salarioBruto - (inss + ir) + salarioFamilia;

            // Formatando para exibição
            DecimalFormat df = new DecimalFormat("0.00");

            // Exibindo os resultados
            tvInss.setText("INSS R$: " + df.format(inss));
            tvIr.setText("IR R$: " + df.format(ir));
            tvSalarioLiquido.setText("Salário Líquido R$: " + df.format(salarioLiquido));

            // Mensagem final com o tratamento
            Toast.makeText(this, tratamento + " " + nome + ", cálculo finalizado!", Toast.LENGTH_LONG).show();

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Por favor, preencha todos os campos corretamente!", Toast.LENGTH_SHORT).show();
        }
    }

    private double calcularINSS(double salario) {
        if (salario <= 1212.00) {
            return salario * 0.075;
        } else if (salario <= 2427.35) {
            return salario * 0.09;
        } else if (salario <= 3641.03) {
            return salario * 0.12;
        } else if (salario <= 7087.22) {
            return salario * 0.14;
        } else {
            return 0; // Para simplificar, não calculamos INSS acima do teto
        }
    }

    private double calcularIR(double salario) {
        if (salario <= 1903.98) {
            return 0;
        } else if (salario <= 2826.65) {
            return salario * 0.075;
        } else if (salario <= 3751.05) {
            return salario * 0.15;
        } else if (salario <= 4664.68) {
            return salario * 0.225;
        } else {
            return salario * 0.275; // IR para salários acima de R$4.664,68
        }
    }
}